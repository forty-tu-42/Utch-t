﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class admin : Window
    {
        private int _currentUserId;

        string ConnectString = "Server=stud-mssql.sttec.yar.ru,38325;" +
                               "Database=user89_db;" +
                               "User Id=user89_db;" +
                               "Password=user89;";

        public admin(int userId = 0)
        {
            InitializeComponent();
            _currentUserId = userId;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadRooms();
            LoadTypes();
            LoadUsers();
        }

        private void LoadRooms()
        {
            string queryString = @"
                SELECT n.id_nomera, n.number, n.vmestimost, n.price,
                       n.opisanie, n.mainimage,
                       ISNULL(t.nazvanie, N'—') AS tip
                FROM NOMERA_Nomera n
                LEFT JOIN NOMERA_Nomer_tip nt ON n.id_nomera = nt.id_nomera
                LEFT JOIN NOMERA_Tipy_nomerov t ON nt.id_type = t.id_type
                ORDER BY n.number;";

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    SqlDataAdapter da = new SqlDataAdapter(queryString, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgRooms.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки номеров: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadTypes()
        {
            try
            {
                TypeCombo.Items.Clear();
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT id_type, nazvanie FROM NOMERA_Tipy_nomerov ORDER BY id_type", con))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            TypeCombo.Items.Add(new ComboBoxItem
                            {
                                Content = reader["nazvanie"].ToString(),
                                Tag = reader["id_type"]
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки типов: " + ex.Message);
            }
        }

        private void dgRooms_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgRooms.SelectedItem is DataRowView row)
            {
                Number.Text = row["number"]?.ToString();
                Capacity.Text = row["vmestimost"]?.ToString();
                Price.Text = row["price"]?.ToString();
                Description.Text = row["opisanie"]?.ToString();
                ImagePath.Text = row["mainimage"]?.ToString();

                string tip = row["tip"]?.ToString();
                TypeCombo.SelectedIndex = -1;
                foreach (ComboBoxItem item in TypeCombo.Items)
                {
                    if (item.Content.ToString() == tip)
                    {
                        TypeCombo.SelectedItem = item;
                        break;
                    }
                }
            }
        }

        private void addnew_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Number.Text) ||
                string.IsNullOrWhiteSpace(Capacity.Text) ||
                string.IsNullOrWhiteSpace(Price.Text))
            {
                MessageBox.Show("Заполните номер, вместимость и цену!");
                return;
            }

            if (!int.TryParse(Capacity.Text, out int cap) || cap <= 0)
            {
                MessageBox.Show("Некорректная вместимость!");
                return;
            }

            if (!decimal.TryParse(Price.Text, out decimal price) || price <= 0)
            {
                MessageBox.Show("Некорректная цена!");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();

                    using (SqlCommand check = new SqlCommand(
                        "SELECT COUNT(*) FROM NOMERA_Nomera WHERE number = @num", con))
                    {
                        check.Parameters.AddWithValue("@num", Number.Text.Trim());
                        if ((int)check.ExecuteScalar() > 0)
                        {
                            MessageBox.Show("Номер с таким номером уже существует!");
                            return;
                        }
                    }

                    string insert = @"
                        INSERT INTO NOMERA_Nomera (number, vmestimost, price, opisanie, mainimage)
                        VALUES (@num, @cap, @price, @desc, @img);
                        SELECT SCOPE_IDENTITY();";

                    int newId;
                    using (SqlCommand cmd = new SqlCommand(insert, con))
                    {
                        cmd.Parameters.AddWithValue("@num", Number.Text.Trim());
                        cmd.Parameters.AddWithValue("@cap", cap);
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.Parameters.AddWithValue("@desc",
                            string.IsNullOrWhiteSpace(Description.Text)
                                ? (object)DBNull.Value : Description.Text.Trim());
                        cmd.Parameters.AddWithValue("@img",
                            string.IsNullOrWhiteSpace(ImagePath.Text)
                                ? (object)DBNull.Value : ImagePath.Text.Trim());

                        newId = Convert.ToInt32(cmd.ExecuteScalar());
                    }

                    if (TypeCombo.SelectedItem is ComboBoxItem typeItem)
                    {
                        using (SqlCommand cmd = new SqlCommand(
                            "INSERT INTO NOMERA_Nomer_tip (id_nomera, id_type) VALUES (@nid, @tid)", con))
                        {
                            cmd.Parameters.AddWithValue("@nid", newId);
                            cmd.Parameters.AddWithValue("@tid", (int)typeItem.Tag);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                MessageBox.Show("Номер добавлен!");
                LoadRooms();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка добавления: " + ex.Message);
            }
        }

        private void izm_Click(object sender, RoutedEventArgs e)
        {
            if (dgRooms.SelectedItem == null)
            {
                MessageBox.Show("Выберите номер!");
                return;
            }

            if (!int.TryParse(Capacity.Text, out int cap) || cap <= 0)
            {
                MessageBox.Show("Некорректная вместимость!");
                return;
            }

            if (!decimal.TryParse(Price.Text, out decimal price) || price <= 0)
            {
                MessageBox.Show("Некорректная цена!");
                return;
            }

            DataRowView row = (DataRowView)dgRooms.SelectedItem;
            int id = Convert.ToInt32(row["id_nomera"]);

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();

                    string update = @"
                        UPDATE NOMERA_Nomera
                        SET number = @num, vmestimost = @cap, price = @price,
                            opisanie = @desc, mainimage = @img
                        WHERE id_nomera = @id";

                    using (SqlCommand cmd = new SqlCommand(update, con))
                    {
                        cmd.Parameters.AddWithValue("@num", Number.Text.Trim());
                        cmd.Parameters.AddWithValue("@cap", cap);
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.Parameters.AddWithValue("@desc",
                            string.IsNullOrWhiteSpace(Description.Text)
                                ? (object)DBNull.Value : Description.Text.Trim());
                        cmd.Parameters.AddWithValue("@img",
                            string.IsNullOrWhiteSpace(ImagePath.Text)
                                ? (object)DBNull.Value : ImagePath.Text.Trim());
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }

                    using (SqlCommand del = new SqlCommand(
                        "DELETE FROM NOMERA_Nomer_tip WHERE id_nomera = @id", con))
                    {
                        del.Parameters.AddWithValue("@id", id);
                        del.ExecuteNonQuery();
                    }

                    if (TypeCombo.SelectedItem is ComboBoxItem typeItem)
                    {
                        using (SqlCommand ins = new SqlCommand(
                            "INSERT INTO NOMERA_Nomer_tip (id_nomera, id_type) VALUES (@nid, @tid)", con))
                        {
                            ins.Parameters.AddWithValue("@nid", id);
                            ins.Parameters.AddWithValue("@tid", (int)typeItem.Tag);
                            ins.ExecuteNonQuery();
                        }
                    }
                }

                MessageBox.Show("Данные обновлены!");
                LoadRooms();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка изменения: " + ex.Message);
            }
        }

        private void del_Click(object sender, RoutedEventArgs e)
        {
            if (dgRooms.SelectedItem == null)
            {
                MessageBox.Show("Выберите номер!");
                return;
            }

            DataRowView row = (DataRowView)dgRooms.SelectedItem;
            int id = Convert.ToInt32(row["id_nomera"]);

            if (MessageBox.Show("Удалить номер?", "Подтверждение",
                MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();

                    using (SqlCommand delLink = new SqlCommand(
                        "DELETE FROM NOMERA_Nomer_tip WHERE id_nomera = @id", con))
                    {
                        delLink.Parameters.AddWithValue("@id", id);
                        delLink.ExecuteNonQuery();
                    }

                    using (SqlCommand cmd = new SqlCommand(
                        "DELETE FROM NOMERA_Nomera WHERE id_nomera = @id", con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Удалено!");
                LoadRooms();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления: " + ex.Message);
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            Number.Text = "";
            Capacity.Text = "";
            Price.Text = "";
            Description.Text = "";
            ImagePath.Text = "";
            TypeCombo.SelectedIndex = -1;
        }

        private void LoadUsers()
        {
            string query = @"
                SELECT p.id_polzovatelya, p.login, p.familiya, p.imya,
                       p.otchestvo, p.tel, p.email,
                       ISNULL(r.nazvanie, N'—') AS role
                FROM NOMERA_Polzovateli p
                LEFT JOIN NOMERA_Roles r ON p.id_role = r.id_role
                ORDER BY p.id_polzovatelya;";

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgUsers.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки пользователей: " + ex.Message);
            }
        }

        private void dgUsers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgUsers.SelectedItem is DataRowView row)
            {
                UserLogin.Text = row["login"]?.ToString();
                UserFam.Text = row["familiya"]?.ToString();
                UserName.Text = row["imya"]?.ToString();
                UserTel.Text = row["tel"]?.ToString();
                UserPassword.Password = "";
            }
        }

        private void AddOperator_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(UserLogin.Text) ||
                string.IsNullOrWhiteSpace(UserPassword.Password) ||
                string.IsNullOrWhiteSpace(UserFam.Text) ||
                string.IsNullOrWhiteSpace(UserName.Text))
            {
                MessageBox.Show("Заполните логин, пароль, фамилию и имя!");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();

                    using (SqlCommand check = new SqlCommand(
                        "SELECT COUNT(*) FROM NOMERA_Polzovateli WHERE login = @login", con))
                    {
                        check.Parameters.AddWithValue("@login", UserLogin.Text.Trim());
                        if ((int)check.ExecuteScalar() > 0)
                        {
                            MessageBox.Show("Логин занят!");
                            return;
                        }
                    }

                    string insert = @"
                        INSERT INTO NOMERA_Polzovateli
                            (login, password, id_role, familiya, imya, tel)
                        VALUES (@login, @pass, 2, @fam, @name, @tel);";

                    using (SqlCommand cmd = new SqlCommand(insert, con))
                    {
                        cmd.Parameters.AddWithValue("@login", UserLogin.Text.Trim());
                        cmd.Parameters.AddWithValue("@pass", UserPassword.Password);
                        cmd.Parameters.AddWithValue("@fam", UserFam.Text.Trim());
                        cmd.Parameters.AddWithValue("@name", UserName.Text.Trim());

                        long tel = 0;
                        if (long.TryParse(UserTel.Text.Trim(), out long t))
                            tel = t;

                        cmd.Parameters.AddWithValue("@tel",
                            tel > 0 ? (object)tel : DBNull.Value);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Оператор добавлен!");
                LoadUsers();
                ClearUserFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка добавления оператора: " + ex.Message);
            }
        }

        private void EditUser_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя!");
                return;
            }

            DataRowView row = (DataRowView)dgUsers.SelectedItem;
            int id = Convert.ToInt32(row["id_polzovatelya"]);

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(@"
                        UPDATE NOMERA_Polzovateli
                        SET familiya = @fam, imya = @name, tel = @tel
                        WHERE id_polzovatelya = @id", con))
                    {
                        cmd.Parameters.AddWithValue("@fam", UserFam.Text.Trim());
                        cmd.Parameters.AddWithValue("@name", UserName.Text.Trim());

                        long tel = 0;
                        if (long.TryParse(UserTel.Text.Trim(), out long t))
                            tel = t;

                        cmd.Parameters.AddWithValue("@tel",
                            tel > 0 ? (object)tel : DBNull.Value);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Данные обновлены!");
                LoadUsers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка изменения: " + ex.Message);
            }
        }

        private void DeleteUser_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя!");
                return;
            }

            DataRowView row = (DataRowView)dgUsers.SelectedItem;
            int id = Convert.ToInt32(row["id_polzovatelya"]);
            if (id == _currentUserId)
            {
                MessageBox.Show("Нельзя удалить собственную учётную запись!");
                return;
            }

            if (MessageBox.Show("Удалить пользователя?", "Подтверждение",
                MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(
                        "DELETE FROM NOMERA_Polzovateli WHERE id_polzovatelya = @id", con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Пользователь удалён!");
                LoadUsers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления: " + ex.Message);
            }
        }

        private void RefreshUsers_Click(object sender, RoutedEventArgs e)
        {
            LoadUsers();
        }

        private void ClearUserFields()
        {
            UserLogin.Text = "";
            UserPassword.Password = "";
            UserFam.Text = "";
            UserName.Text = "";
            UserTel.Text = "";
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }
    }
}