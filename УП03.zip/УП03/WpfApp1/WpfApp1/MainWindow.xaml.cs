﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        string ConnectString = "Server=stud-mssql.sttec.yar.ru,38325;" +
                               "Database=user89_db;" +
                               "User Id=user89_db;" +
                               "Password=user89;";

        private void Authorization_Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Login_Box.Text) ||
                string.IsNullOrWhiteSpace(Password_Box1.Password))
            {
                MessageBox.Show("Введите логин и пароль!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    string query = "SELECT id_polzovatelya, id_role " +
                                   "FROM NOMERA_Polzovateli " +
                                   "WHERE login = @login AND password = @password";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@login", Login_Box.Text.Trim());
                        cmd.Parameters.AddWithValue("@password", Password_Box1.Password);

                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int userId = reader.GetInt32(reader.GetOrdinal("id_polzovatelya")); 
                                int roleId = reader.GetInt32(reader.GetOrdinal("id_role"));
                                MessageBox.Show("Данные верны! Пройдите проверку капчи.",
                                    "Авторизация", MessageBoxButton.OK,
                                    MessageBoxImage.Information);

                                CapthcaWin captcha = new CapthcaWin(userId, roleId);
                                captcha.Show();
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Неверный логин или пароль",
                                    "Ошибка", MessageBoxButton.OK,
                                    MessageBoxImage.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка авторизации: {ex.Message}");
            }
        }

        private void Registration_Button_Click(object sender, RoutedEventArgs e)
        {
            RegistrationWindow reg = new RegistrationWindow();
            reg.Show();
            this.Close();
        }
    }
}
