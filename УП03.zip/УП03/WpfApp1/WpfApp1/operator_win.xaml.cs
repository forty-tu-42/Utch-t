﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class operator_win : Window
    {

        string ConnectString = "Server=stud-mssql.sttec.yar.ru,38325;" +
                               "Database=user89_db;" +
                               "User Id=user89_db;" +
                               "Password=user89;";

        public operator_win()
        {
            InitializeComponent();
        }

        // ================= ЗАГРУЗКА =================
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadBron();
            LoadRooms();
            LoadUsers();
        }

        // ============ БРОНИРОВАНИЯ ============
        private void LoadBron()
        {
            string query = @"
                SELECT b.id_bronirovaniya,
                       ISNULL(p.familiya, N'') + ' ' + ISNULL(p.imya, N'') AS client,
                       n.number,
                       b.data_zaezda,
                       b.data_vyiezda,
                       b.data_bronirovaniya,
                       b.status
                FROM NOMERA_Bron b
                JOIN NOMERA_Polzovateli p ON b.id_polzovatelya = p.id_polzovatelya
                JOIN NOMERA_Nomera n ON b.id_nomera = n.id_nomera
                ORDER BY b.data_bronirovaniya DESC;";

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgBron.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки броней: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void dgBron_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Заглушка — можно использовать для подсветки/деталей
        }

        // Подтвердить бронь — статус «Подтверждена»
        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            ChangeStatus("Подтверждена");
        }

        // Отменить бронь — статус «Отменена»
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Отменить выбранную бронь?",
                    "Подтверждение", MessageBoxButton.YesNo,
                    MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            ChangeStatus("Отменена");
        }

        // Смена статуса брони
        private void ChangeStatus(string newStatus)
        {
            if (dgBron.SelectedItem == null)
            {
                MessageBox.Show("Выберите бронь!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)dgBron.SelectedItem;
            int id = Convert.ToInt32(row["id_bronirovaniya"]);
            string currentStatus = row["status"].ToString();

            if (currentStatus == newStatus)
            {
                MessageBox.Show($"Бронь уже в статусе «{newStatus}».");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(
                        "UPDATE NOMERA_Bron SET status = @s WHERE id_bronirovaniya = @id", con))
                    {
                        cmd.Parameters.AddWithValue("@s", newStatus);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show($"Статус изменён на «{newStatus}».",
                    "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadBron();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка смены статуса: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            LoadBron();
        }

        // ============ НОМЕРА ============
        private void LoadRooms()
        {
            string query = @"
                SELECT n.id_nomera, n.number, n.vmestimost, n.price,
                       n.opisanie, n.mainimage, t.nazvanie AS tip
                FROM NOMERA_Nomera n
                LEFT JOIN NOMERA_Nomer_tip nt ON n.id_nomera = nt.id_nomera
                LEFT JOIN NOMERA_Tipy_nomerov t ON nt.id_type = t.id_type
                ORDER BY n.number;";

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgRooms.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки номеров: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void dgRooms_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgRooms.SelectedItem is DataRowView row)
            {
                PriceBox.Text = row["price"]?.ToString();
                CapacityBox.Text = row["vmestimost"]?.ToString();
                DescBox.Text = row["opisanie"]?.ToString();
            }
        }

        // Редактирование номера (цена, вместимость, описание)
        private void EditRoom_Click(object sender, RoutedEventArgs e)
        {
            if (dgRooms.SelectedItem == null)
            {
                MessageBox.Show("Выберите номер!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(PriceBox.Text) ||
                string.IsNullOrWhiteSpace(CapacityBox.Text))
            {
                MessageBox.Show("Заполните цену и вместимость!");
                return;
            }

            if (!decimal.TryParse(PriceBox.Text, out decimal price) || price <= 0)
            {
                MessageBox.Show("Некорректная цена!");
                return;
            }

            if (!int.TryParse(CapacityBox.Text, out int cap) || cap <= 0)
            {
                MessageBox.Show("Некорректная вместимость!");
                return;
            }

            DataRowView row = (DataRowView)dgRooms.SelectedItem;
            int id = Convert.ToInt32(row["id_nomera"]);

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(@"
                        UPDATE NOMERA_Nomera
                        SET price = @price, vmestimost = @cap, opisanie = @desc
                        WHERE id_nomera = @id", con))
                    {
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.Parameters.AddWithValue("@cap", cap);
                        cmd.Parameters.AddWithValue("@desc",
                            string.IsNullOrWhiteSpace(DescBox.Text)
                                ? (object)DBNull.Value : DescBox.Text.Trim());
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Данные номера обновлены!");
                LoadRooms();
                PriceBox.Text = "";
                CapacityBox.Text = "";
                DescBox.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка изменения: " + ex.Message);
            }
        }

        private void RefreshRooms_Click(object sender, RoutedEventArgs e)
        {
            LoadRooms();
        }

        // ============ ПОЛЬЗОВАТЕЛИ ============
        private void LoadUsers()
        {
            string query = @"
                SELECT p.id_polzovatelya, p.login, p.familiya, p.imya,
                       p.otchestvo, p.tel, p.email,
                       r.nazvanie AS role
                FROM NOMERA_Polzovateli p
                LEFT JOIN NOMERA_Roles r ON p.id_role = r.id_role
                ORDER BY p.id_polzovatelya;";

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgUsers.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки пользователей: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ============ НАЗАД ============
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }
    }
}