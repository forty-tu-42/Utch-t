﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class user : Window
    {
        private int _currentUserId;

        string ConnectString = "Server=stud-mssql.sttec.yar.ru,38325;" +
                               "Database=user89_db;" +
                               "User Id=user89_db;" +
                               "Password=user89;";

        // Конструктор принимает ID клиента
        public user(int userId)
        {
            InitializeComponent();
            _currentUserId = userId;
        }

        // ================= ЗАГРУЗКА =================
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadRooms();
            dgRooms.Visibility = Visibility.Visible;
            dgBookings.Visibility = Visibility.Collapsed;
        }

        // ============ ЗАГРУЗКА НОМЕРОВ ============
        private void LoadRooms()
        {
            string query = @"
                SELECT n.id_nomera, n.number, n.vmestimost, n.price,
                       n.opisanie, n.mainimage,
                       ISNULL(t.nazvanie, N'—') AS tip,
                       CASE
                           WHEN EXISTS (
                               SELECT 1 FROM NOMERA_Bron b
                               WHERE b.id_nomera = n.id_nomera
                                 AND b.status = N'Активна'
                                 AND b.data_vyiezda >= CAST(GETDATE() AS date)
                           ) THEN N'Занят'
                           ELSE N'Свободен'
                       END AS status
                FROM NOMERA_Nomera n
                LEFT JOIN NOMERA_Nomer_tip nt ON n.id_nomera = nt.id_nomera
                LEFT JOIN NOMERA_Tipy_nomerov t ON nt.id_type = t.id_type
                ORDER BY n.number;";

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Добавляем колонку imagePath с абсолютным путём
                    if (!dt.Columns.Contains("imagePath"))
                        dt.Columns.Add("imagePath", typeof(string));

                    foreach (DataRow row in dt.Rows)
                    {
                        string path = row["mainimage"]?.ToString();
                        if (string.IsNullOrWhiteSpace(path))
                        {
                            row["imagePath"] = null;
                            continue;
                        }

                        if (!Path.IsPathRooted(path))
                            path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, path);

                        row["imagePath"] = File.Exists(path) ? path : null;
                    }

                    dgRooms.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки номеров: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ============ РАСЧЁТ ИТОГОВОЙ СТОИМОСТИ ============
        private void UpdateTotalPrice()
        {
            TotalPrice.Text = "0 ₽";

            if (dgRooms.SelectedItem == null) return;
            if (DateIn.SelectedDate == null || DateOut.SelectedDate == null) return;
            if (DateIn.SelectedDate >= DateOut.SelectedDate) return;

            DataRowView row = (DataRowView)dgRooms.SelectedItem;

            if (!decimal.TryParse(row["price"].ToString(), out decimal price))
                return;

            int days = (DateOut.SelectedDate.Value - DateIn.SelectedDate.Value).Days;
            if (days <= 0) return;

            TotalPrice.Text = $"{price * days:N0} ₽ ({days} сут.)";
        }

        private void Date_Changed(object sender, SelectionChangedEventArgs e)
        {
            UpdateTotalPrice();
        }

        // ============ БРОНИРОВАНИЕ ============
        private void Book_Click(object sender, RoutedEventArgs e)
        {
            if (dgRooms.SelectedItem == null)
            {
                MessageBox.Show("Выберите номер!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (DateIn.SelectedDate == null || DateOut.SelectedDate == null)
            {
                MessageBox.Show("Укажите даты заезда и выезда!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (DateIn.SelectedDate >= DateOut.SelectedDate)
            {
                MessageBox.Show("Дата выезда должна быть позже даты заезда!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)dgRooms.SelectedItem;
            int roomId = Convert.ToInt32(row["id_nomera"]);

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();

                    // Проверка пересечения дат
                    using (SqlCommand check = new SqlCommand(@"
                        SELECT COUNT(*) FROM NOMERA_Bron
                        WHERE id_nomera = @room
                          AND status = N'Активна'
                          AND (@in <= data_vyiezda AND @out >= data_zaezda)", con))
                    {
                        check.Parameters.AddWithValue("@room", roomId);
                        check.Parameters.AddWithValue("@in", DateIn.SelectedDate.Value);
                        check.Parameters.AddWithValue("@out", DateOut.SelectedDate.Value);

                        if ((int)check.ExecuteScalar() > 0)
                        {
                            MessageBox.Show("Номер занят на выбранные даты.",
                                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                            return;
                        }
                    }

                    // INSERT с реальным ID пользователя
                    string insert = @"INSERT INTO NOMERA_Bron
                        (id_polzovatelya, id_nomera, data_zaezda, data_vyiezda, status)
                        VALUES (@uid, @nid, @in, @out, N'Активна')";

                    using (SqlCommand cmd = new SqlCommand(insert, con))
                    {
                        cmd.Parameters.AddWithValue("@uid", _currentUserId);
                        cmd.Parameters.AddWithValue("@nid", roomId);
                        cmd.Parameters.AddWithValue("@in", DateIn.SelectedDate.Value);
                        cmd.Parameters.AddWithValue("@out", DateOut.SelectedDate.Value);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Бронирование оформлено!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                DateIn.SelectedDate = null;
                DateOut.SelectedDate = null;
                TotalPrice.Text = "0 ₽";
                LoadRooms();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка бронирования: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ============ ОТМЕНА БРОНИ ============
        private void CancelBooking_Click(object sender, RoutedEventArgs e)
        {
            if (dgBookings.Visibility == Visibility.Visible)
            {
                if (dgBookings.SelectedItem == null)
                {
                    MessageBox.Show("Выберите бронь для отмены!", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                DataRowView row = (DataRowView)dgBookings.SelectedItem;
                int id = Convert.ToInt32(row["id_bronirovaniya"]);
                string status = row["status"].ToString();

                if (status == "Отменена")
                {
                    MessageBox.Show("Эта бронь уже отменена.");
                    return;
                }

                if (MessageBox.Show("Отменить выбранную бронь?",
                        "Подтверждение", MessageBoxButton.YesNo,
                        MessageBoxImage.Question) != MessageBoxResult.Yes)
                    return;

                try
                {
                    using (SqlConnection con = new SqlConnection(ConnectString))
                    {
                        con.Open();
                        using (SqlCommand cmd = new SqlCommand(@"
                            UPDATE NOMERA_Bron
                            SET status = N'Отменена'
                            WHERE id_bronirovaniya = @id
                              AND id_polzovatelya = @uid", con))
                        {
                            cmd.Parameters.AddWithValue("@id", id);
                            cmd.Parameters.AddWithValue("@uid", _currentUserId);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Бронь отменена.");
                    MyBookings_Click(null, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка отмены: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Откройте «Мои брони» и выберите бронь для отмены.",
                    "Подсказка", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void MyBookings_Click(object sender, RoutedEventArgs e)
        {
            string query = @"
                SELECT b.id_bronirovaniya, n.number, b.data_zaezda,
                       b.data_vyiezda, b.data_bronirovaniya, b.status
                FROM NOMERA_Bron b
                JOIN NOMERA_Nomera n ON b.id_nomera = n.id_nomera
                WHERE b.id_polzovatelya = @uid
                ORDER BY b.data_bronirovaniya DESC;";

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                    adapter.SelectCommand.Parameters.AddWithValue("@uid", _currentUserId);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgBookings.ItemsSource = dt.DefaultView;
                    dgRooms.Visibility = Visibility.Collapsed;
                    dgBookings.Visibility = Visibility.Visible;

                    if (dgBookings.Items.Count == 0)
                        MessageBox.Show("У вас пока нет бронирований.",
                            "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки броней: " + ex.Message);
            }
        }

        private void ShowRooms_Click(object sender, RoutedEventArgs e)
        {
            LoadRooms();
            dgRooms.Visibility = Visibility.Visible;
            dgBookings.Visibility = Visibility.Collapsed;
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }
    }
}