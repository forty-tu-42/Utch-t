﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class CapthcaWin : Window
    {
        private readonly Random _random = new Random();

        private int _userId;  
        private int _userRole;    
        private bool _isRegistration;

        private string _correctCode = "";
        private const string Chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
        private const int CodeLength = 5;

        // Конструктор принимает и ID, и роль
        public CapthcaWin(int userId, int role, bool isRegistration = false)
        {
            InitializeComponent();
            _userId = userId;
            _userRole = role;
            _isRegistration = isRegistration;

            GenerateCaptcha();
        }
        // Генерация нового кода капчи
        private void GenerateCaptcha()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < CodeLength; i++)
            {
                sb.Append(Chars[_random.Next(Chars.Length)]);
            }
            _correctCode = sb.ToString();
            CaptchaText.Text = _correctCode;
            InputBox.Text = "";
        }

        private void ProceedAfterCaptcha()
        {
            if (_isRegistration)
            {
                MessageBox.Show("Регистрация успешно завершена!");
                // Передаём ID в user
                new MainWindow().Show();
            }
            else
            {
                switch (_userRole)
                {
                    case 1:  // Клиент
                        MessageBox.Show("Доступ: Клиент");
                        new user(_userId).Show();
                        break;

                    case 2:  // Оператор
                        MessageBox.Show("Доступ: Оператор");
                        new operator_win().Show();
                        break;

                    case 3:  // Администратор
                        MessageBox.Show("Доступ: Администратор системы");
                        new admin().Show();
                        break;

                    default:
                        MessageBox.Show("Неизвестная роль!");
                        new MainWindow().Show();
                        break;
                }
            }
            this.Close();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            GenerateCaptcha();
        }

        private void CheckButton_Click(object sender, RoutedEventArgs e)
        {
            string userInput = InputBox.Text.Trim().ToUpper();

            if (string.IsNullOrEmpty(userInput))
            {
                MessageBox.Show("Введите код с картинки!",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (userInput == _correctCode)
            {
                MessageBox.Show("Капча пройдена верно!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                ProceedAfterCaptcha();
            }
            else
            {
                MessageBox.Show("Неверный код. Попробуйте ещё раз.",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                GenerateCaptcha();  // обновить капчу
            }
        }
    }
    }