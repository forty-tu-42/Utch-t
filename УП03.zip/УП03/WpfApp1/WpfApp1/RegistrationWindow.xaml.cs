﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class RegistrationWindow : Window
    {
        public RegistrationWindow()
        {
            InitializeComponent();
        }

        string ConnectString = "Server=stud-mssql.sttec.yar.ru,38325;" +
                               "Database=user89_db;" +
                               "User Id=user89_db;" +
                               "Password=user89;";
        private void Register_Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Login_Box.Text) ||
                string.IsNullOrWhiteSpace(Password_Box1.Password) ||
                string.IsNullOrWhiteSpace(Fam_Box.Text) ||
                string.IsNullOrWhiteSpace(Name_Box.Text))
            {
                MessageBox.Show("Заполните обязательные поля: Фамилия, Имя, Логин, Пароль!",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                int newUserId = 0;

                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();

                    using (SqlCommand check = new SqlCommand(
                        "SELECT COUNT(*) FROM NOMERA_Polzovateli WHERE login = @login", con))
                    {
                        check.Parameters.AddWithValue("@login", Login_Box.Text.Trim());
                        if ((int)check.ExecuteScalar() > 0)
                        {
                            MessageBox.Show("Логин занят!");
                            return;
                        }
                    }

                    string insert = @"INSERT INTO NOMERA_Polzovateli
                (login, password, id_role, familiya, imya, otchestvo, tel, email)
                VALUES (@login, @password, 1, @fam, @name, @otc, @tel, @email);
                SELECT SCOPE_IDENTITY();";

                    using (SqlCommand cmd = new SqlCommand(insert, con))
                    {
                        cmd.Parameters.AddWithValue("@login", Login_Box.Text.Trim());
                        cmd.Parameters.AddWithValue("@password", Password_Box1.Password);
                        cmd.Parameters.AddWithValue("@fam", Fam_Box.Text.Trim());
                        cmd.Parameters.AddWithValue("@name", Name_Box.Text.Trim());
                        cmd.Parameters.AddWithValue("@otc",
                            string.IsNullOrWhiteSpace(Otc_Box.Text) ? (object)DBNull.Value : Otc_Box.Text.Trim());
                        cmd.Parameters.AddWithValue("@tel",
                            string.IsNullOrWhiteSpace(Tel_Box.Text) ? (object)DBNull.Value : long.Parse(Tel_Box.Text.Trim()));
                        cmd.Parameters.AddWithValue("@email",
                            string.IsNullOrWhiteSpace(Email_Box.Text) ? (object)DBNull.Value : Email_Box.Text.Trim());

                        newUserId = Convert.ToInt32(cmd.ExecuteScalar());  
                    }
                }

                MessageBox.Show("Регистрация успешна! Пройдите капчу.");

                CapthcaWin captcha = new CapthcaWin(newUserId, 1, isRegistration: true);
                captcha.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка регистрации: " + ex.Message);
            }
        }

        private void Back_Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
    }
}
